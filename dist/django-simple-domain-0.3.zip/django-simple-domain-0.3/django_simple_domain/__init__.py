default_app_config = 'django_simple_domain.app.DjangoSimpleSiteConfig'
